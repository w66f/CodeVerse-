// تهيئة المحررات
const editors = {
  html: document.getElementById('htmlEditor'),
  css: document.getElementById('cssEditor'),
  js: document.getElementById('jsEditor')
};

// تحديث أرقام الأسطر
function updateLineNumbers(editor, lineNumbers) {
  const lines = editor.value.split('\n').length;
  lineNumbers.innerHTML = Array(lines).fill('').map((_, i) => i + 1).join('<br>');
}

// التمرير المتزامن
function syncScroll(editor, lineNumbers) {
  lineNumbers.scrollTop = editor.scrollTop;
}

// تهيئة الأحداث
Object.entries(editors).forEach(([type, editor]) => {
  const lineNumbers = document.getElementById(`${type}LineNumbers`);
  
  editor.addEventListener('input', () => {
    updateLineNumbers(editor, lineNumbers);
    updatePreview();
    localStorage.setItem(`${type}Code`, editor.value);
  });
  
  editor.addEventListener('scroll', () => syncScroll(editor, lineNumbers));
});

// المعاينة التلقائية
function updatePreview() {
  const preview = document.getElementById('preview');
  preview.innerHTML = `
    <html>
      <head><style>${editors.css.value}</style></head>
      <body>${editors.html.value}</body>
      <script>${editors.js.value}</script>
    </html>
  `;
}

// فتح في متصفح
function openInBrowser() {
  const newWindow = window.open();
  newWindow.document.write(`
    <!DOCTYPE html>
    <html>
      <head><style>${editors.css.value}</style></head>
      <body>${editors.html.value}</body>
      <script>${editors.js.value}</script>
    </html>
  `);
}

// تحميل كمشروع ZIP
function downloadProject() {
  const zip = new JSZip();
  zip.file("index.html", editors.html.value);
  zip.file("style.css", editors.css.value);
  zip.file("script.js", editors.js.value);
  
  zip.generateAsync({ type: "blob" }).then(blob => {
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'project.zip';
    link.click();
  });
}

// مسح الكود
function clearCode(type) {
  if (confirm(`هل تريد مسح ${type.toUpperCase()}؟`)) {
    editors[type].value = '';
    localStorage.removeItem(`${type}Code`);
    updateLineNumbers(editors[type], document.getElementById(`${type}LineNumbers`));
    updatePreview();
  }
}

// التهيئة الأولية
window.onload = () => {
  Object.entries(editors).forEach(([type, editor]) => {
    editor.value = localStorage.getItem(`${type}Code`) || '';
    updateLineNumbers(editor, document.getElementById(`${type}LineNumbers`));
  });
  updatePreview();
};